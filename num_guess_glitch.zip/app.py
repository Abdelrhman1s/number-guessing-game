from flask import Flask, render_template, request, session, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = 'supersecretkey'

@app.route('/', methods=['GET', 'POST'])
def index():
    if 'num' not in session or 'guesses' not in session or 'max_guesses' not in session:
        session['num'] = random.randint(1, 100)
        session['guesses'] = 0
        session['max_guesses'] = 10

    message = ""
    win = False
    lose = False
    if request.method == 'POST':
        guess = int(request.form['guess'])
        session['guesses'] += 1
        if guess == session['num']:
            message = "Correct! 🎉"
            win = True
        elif guess < session['num']:
            message = "Too low!"
        else:
            message = "Too high!"

        if session['guesses'] >= session['max_guesses'] and not win:
            message = f"You lose! The number was {session['num']}."
            lose = True

    return render_template('game.html',
                           message=message,
                           guesses=session['max_guesses'] - session['guesses'],
                           win=win,
                           lose=lose)

@app.route('/reset')
def reset():
    session.clear()
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
